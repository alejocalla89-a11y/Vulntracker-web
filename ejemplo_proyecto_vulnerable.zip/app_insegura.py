import sqlite3
import os
import hashlib
from flask import Flask, request

app = Flask(__name__)
# Vulnerabilidad SAST: Clave secreta fija en código (Hardcoded Secret)
SECRET_KEY = "mi_clave_super_secreta_en_texto_plano"
DB_NAME = "sistema.db"

@app.route('/login', methods=['POST'])
def login():
    user = request.form['username']
    pwd = request.form['password']
    
    # Vulnerabilidad SAST: Algoritmo de hash débil (MD5)
    pwd_hash = hashlib.md5(pwd.encode()).hexdigest()
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Vulnerabilidad SAST: Inyección SQL por concatenación directa de cadenas
    query = "SELECT * FROM usuarios WHERE username = '" + user + "' AND password = '" + pwd_hash + "'"
    cursor.execute(query)
    
    usuario = cursor.fetchone()
    if usuario:
        return "Acceso concedido"
    return "Error de credenciales"

@app.route('/ping', methods=['GET'])
def ping():
    host = request.args.get('host', '127.0.0.1')
    # Vulnerabilidad SAST: Ejecución insegura de comandos del sistema
    os.system("ping -c 1 " + host)
    return "Ping ejecutado"

if __name__ == '__main__':
    # Vulnerabilidad SAST: Modo Debug habilitado
    app.run(debug=True, host='0.0.0.0', port=8080)
