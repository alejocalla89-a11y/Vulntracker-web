using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace SistemaEmpresarialVulnerable
{
    public class ServicioVulnerable
    {
        // 1. FILTRACIÓN DE CLAVE DE IA (2026 AI Threat)
        private const string OpenAIKey = "sk-proj-a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0uvwx";
        
        // 2. CREDENCIAL O TOKEN DE AUTENTICACIÓN HARDCODED
        private string SecretToken = "super_secret_auth_token_9988";

        public void ProcesarConsultaUsuario(string userInput, string cadenaConexion)
        {
            // 3. INYECCIÓN SQL EN C# (.NET)
            using (SqlConnection connection = new SqlConnection(cadenaConexion))
            {
                connection.Open();
                string sql = $"SELECT * FROM Usuarios WHERE NombreUsuario = '{userInput}' AND Estado = 1";
                SqlCommand command = new SqlCommand(sql, connection);
                SqlDataReader reader = command.ExecuteReader();
            }
        }

        public void EjecutarDiagnosticoRed(string IP)
        {
            // 4. EJECUCIÓN INSEGURA DE COMANDOS DEL SISTEMA (Process.Start)
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = "cmd.exe";
            psi.Arguments = $"/c ping {IP}";
            Process.Start(psi);
        }

        public object DeserializarDatosInseguros(byte[] buffer)
        {
            // 5. DESERIALIZACIÓN INSEGURA BINARYFORMATTER
            BinaryFormatter formatter = new BinaryFormatter();
            MemoryStream ms = new MemoryStream(buffer);
            return formatter.Deserialize(ms);
        }

        public string GenerarHashMD5(string texto)
        {
            #pragma warning disable CS0618
            // 6. USO DE CRIPTOGRAFÍA DÉBIL (MD5)
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.UTF8.GetBytes(texto);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            return Convert.ToHexString(hashBytes);
        }
    }
}
